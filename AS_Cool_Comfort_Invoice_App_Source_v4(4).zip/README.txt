AS COOL COMFORT INVOICE APP

Included:
- Offline invoice maker for AC service/repair/installations
- Customer and business details
- Optional GST (0%, 5%, 12%, 18%, 28%)
- Multiple line items, quantity, rate and totals
- Save/open/delete invoices on the same device
- Print / Save as PDF and share summary
- Android Studio WebView project source

IMPORTANT:
This ZIP contains the Android Studio project source, not a compiled APK.
To build the APK: open this folder in Android Studio, allow Gradle sync, then choose
Build > Build Bundle(s) / APK(s) > Build APK(s).
The APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

The app stores invoices locally on the phone. Export/backup your PDFs separately.
Business address, phone and GSTIN can be filled in inside the app.
